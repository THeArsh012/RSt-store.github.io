
  # Website Design Inspiration

  This is a code bundle for Website Design Inspiration. The original project is available at https://www.figma.com/design/KUyjBoEHZuHnQW1p16ybOC/Website-Design-Inspiration.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  