import { Toaster } from 'sonner';
import { CartProvider } from './context/CartContext';
import { Navigation } from './components/Navigation';
import { Hero } from './components/Hero';
import { Products } from './components/Products';
import { Features } from './components/Features';
import { Stats } from './components/Stats';
import { Services } from './components/Services';
import { Contact } from './components/Contact';
import { Checkout } from './components/Checkout';
import { Footer } from './components/Footer';
import { Cart } from './components/Cart';

export default function App() {
  return (
    <CartProvider>
      <div className="min-h-screen bg-black text-white overflow-x-hidden">
        <Toaster position="top-right" theme="dark" />
        <Navigation />
        <Hero />
        <Products />
        <Features />
        <Stats />
        <Services />
        <Contact />
        <Checkout />
        <Footer />
        <Cart />
      </div>
    </CartProvider>
  );
}
