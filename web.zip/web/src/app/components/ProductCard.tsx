import { motion } from 'motion/react';
import { ShoppingCart } from 'lucide-react';
import { Product } from '../data/productsData';
import { useCart } from '../context/CartContext';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { toast } from 'sonner';

interface ProductCardProps {
  product: Product;
}

export function ProductCard({ product }: ProductCardProps) {
  const { addToCart } = useCart();

  const handleAddToCart = () => {
    addToCart(product);
    toast.success(`${product.name} added to cart!`);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ y: -5 }}
      className="group relative bg-gradient-to-br from-white/5 to-white/0 border border-white/10 rounded-2xl overflow-hidden backdrop-blur-sm hover:border-purple-500/50 transition-all duration-300"
    >
      {/* Product Image */}
      <div className="relative h-56 overflow-hidden">
        <ImageWithFallback
          src={product.image}
          alt={product.name}
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-60" />
        
        {/* Stock Badge */}
        {product.inStock && (
          <div className="absolute top-4 right-4 px-3 py-1 bg-green-500/20 border border-green-500/50 rounded-full backdrop-blur-sm">
            <span className="text-xs text-green-400">In Stock</span>
          </div>
        )}
      </div>

      {/* Product Info */}
      <div className="p-6">
        <div className="mb-2">
          <span className="text-xs text-purple-400 uppercase tracking-wider">
            {product.category}
          </span>
        </div>
        <h3 className="text-white mb-2 line-clamp-1">{product.name}</h3>
        <p className="text-gray-400 text-sm mb-4 line-clamp-2">
          {product.description}
        </p>

        {/* Price and Add to Cart */}
        <div className="flex items-center justify-between">
          <div>
            <span className="text-2xl bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
              ${product.price}
            </span>
          </div>
          <button
            onClick={handleAddToCart}
            className="group/btn px-4 py-2 bg-gradient-to-r from-purple-500 to-pink-500 rounded-lg text-white hover:shadow-lg hover:shadow-purple-500/50 transition-all duration-300 flex items-center gap-2"
          >
            <ShoppingCart size={18} className="group-hover/btn:scale-110 transition-transform" />
            <span className="text-sm">Add</span>
          </button>
        </div>
      </div>
    </motion.div>
  );
}
